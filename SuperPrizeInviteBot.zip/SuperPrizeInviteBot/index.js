// index.js (ESM)
import fs from "fs";
import path from "path";
import TelegramBot from "node-telegram-bot-api";
import dotenv from "dotenv";

dotenv.config();

// === CONFIG (через .env) ===
const BOT_TOKEN = process.env.BOT_TOKEN || "";
const ADMIN_ID = Number(process.env.ADMIN_ID || 0);
const CHANNEL_ID = process.env.CHANNEL_ID || ""; // например: -1003263351790
const CHANNEL_USERNAME = (process.env.CHANNEL_USERNAME || "").replace(/^@/, "");
const MIN_PAYOUT = Number(process.env.MIN_PAYOUT || 150);
const INVITE_REWARD = Number(process.env.INVITE_REWARD || 5);
const TICKETS_FOR_SPIN = Number(process.env.TICKETS_FOR_SPIN || 7);

if (!BOT_TOKEN) {
  console.error("ERROR: BOT_TOKEN не задан в .env");
  process.exit(1);
}
if (!ADMIN_ID) console.warn("WARNING: ADMIN_ID не задан — админ-уведомления не будут работать.");

// === data file ===
const DATA_FILE = path.resolve("./data.json");
function readData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(raw);
  } catch (e) {
    return { users: {}, referrals: {}, withdrawals: [], promos: { real: [], fake: [] } };
  }
}
function writeData(d) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
}

// === Telegram бот (polling) ===
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
console.log("Bot started (polling).");

// === Helpers ===
function ensureUserObj(data, from) {
  const id = String(from.id);
  if (!data.users[id]) {
    data.users[id] = {
      id: Number(id),
      username: from.username || "",
      first_name: from.first_name || "",
      tickets: 0,
      balance: 0,
      invites: [],
      ref_by: null
    };
    writeData(data);
  }
  return data.users[id];
}
function addReferral(inviterId, newId) {
  const data = readData();
  inviterId = String(inviterId);
  newId = String(newId);
  if (!data.users[inviterId]) {
    data.users[inviterId] = { id: Number(inviterId), username: "", first_name: "", tickets: 0, balance: 0, invites: [], ref_by: null };
  }
  if (!data.users[inviterId].invites) data.users[inviterId].invites = [];
  if (!data.users[inviterId].invites.includes(newId)) {
    data.users[inviterId].invites.push(newId);
    data.users[inviterId].tickets = (data.users[inviterId].tickets || 0) + 1;
    data.users[inviterId].balance = (data.users[inviterId].balance || 0) + INVITE_REWARD;
    writeData(data);
    return true;
  }
  return false;
}
function genFakePromo() {
  const part = () => Math.random().toString(36).substring(2, 7).toUpperCase();
  return `SALE-${part()}-${Math.floor(Math.random()*90+10)}`;
}

// === Рулетка: вероятности по твоему запросу ===
// ❌ Ничего 20%
// 🎟 +3 билета 45%
// 💰 10₽ 21%
// 💰 20₽ 10%
// 💎 50₽ 4%
function spinPrize() {
  const r = Math.random()*100;
  if (r < 20) return { type: "nothing" };
  if (r < 20 + 45) return { type: "tickets", count: 3 };
  if (r < 20 + 45 + 21) return { type: "money", amount: 10 };
  if (r < 20 + 45 + 21 + 10) return { type: "money", amount: 20 };
  return { type: "money", amount: 50 }; // остаток ~4%
}

// === Inline main menu (нижняя панель inline) ===
function mainMenuInline() {
  const channelUrl = CHANNEL_USERNAME
    ? `https://t.me/${CHANNEL_USERNAME}`
    : (CHANNEL_ID ? `https://t.me/${String(CHANNEL_ID).replace(/^-100/, "")}` : "");
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: "👤 Мой профиль", callback_data: "menu_profile" }],
        [{ text: "👥 Пригласить друзей", callback_data: "menu_ref" }, { text: "🎡 Рулетка", callback_data: "menu_spin" }],
        [{ text: "💳 Вывод", callback_data: "menu_withdraw" }, { text: "📜 Правила", callback_data: "menu_rules" }],
        [{ text: "📣 Подписаться на канал", url: channelUrl }, { text: "✅ Проверить подписку", callback_data: "menu_check_sub" }]
      ]
    }
  };
}

// === /start [ref] ===
bot.onText(/^\/start(?:\s+(.+))?/, async (msg, match) => {
  const from = msg.from;
  const chatId = msg.chat.id;
  const data = readData();
  ensureUserObj(data, from);

  const param = match && match[1] ? match[1].trim() : null;
  if (param) {
    const digits = param.match(/\d+/);
    if (digits) {
      const refId = digits[0];
      if (String(refId) !== String(from.id) && !data.users[String(from.id)].ref_by) {
        data.users[String(from.id)].ref_by = String(refId);
        // не добавляем в referrals до /confirm
        writeData(data);
        bot.sendMessage(chatId, `Спасибо! Вы пришли по приглашению. Подпишитесь на канал и введите /confirm чтобы приглашение засчиталось.`, mainMenuInline());
        if (ADMIN_ID) {
          try { bot.sendMessage(ADMIN_ID, `Новый пришёл по рефке: inviter=${refId} new=${from.id}`); } catch(e){}
        }
        return;
      }
    }
  }

  const me = await bot.getMe();
  const refLink = `https://t.me/${me.username}?start=${from.id}`;
  const welcome = `🔥 Добро пожаловать в СуперПрайз — бот, где можно заработать за приглашения!\n\n1 приглашённый = ${INVITE_REWARD}₽ и +1 билет.\nТвоя реферальная ссылка:\n${refLink}\n\nПодпишись на канал и введите /confirm после подписки.`;
  bot.sendMessage(chatId, welcome, mainMenuInline());
});

// === /confirm (пользователь подтверждает подписку на канал) ===
bot.onText(/^\/confirm$/, async (msg) => {
  const from = msg.from;
  const chatId = msg.chat.id;
  const data = readData();
  const user = data.users[String(from.id)];
  if (!user || !user.ref_by) {
    return bot.sendMessage(chatId, "Мы не видим, что вы пришли по реферальной ссылке.", mainMenuInline());
  }
  const channelTarget = CHANNEL_ID || (CHANNEL_USERNAME ? `@${CHANNEL_USERNAME}` : null);
  if (!channelTarget) {
    return bot.sendMessage(chatId, "Канал не настроен у бота. Свяжитесь с админом.", mainMenuInline());
  }

  try {
    const member = await bot.getChatMember(channelTarget, from.id);
    if (member && (member.status === "member" || member.status === "creator" || member.status === "administrator")) {
      const inviter = String(user.ref_by);
      const ok = addReferral(inviter, from.id);
      if (ok) {
        // отмечаем в referrals
        if (!data.referrals[inviter]) data.referrals[inviter] = [];
        if (!data.referrals[inviter].includes(String(from.id))) data.referrals[inviter].push(String(from.id));
        writeData(data);
        bot.sendMessage(chatId, `Спасибо! Подписка подтверждена — приглашение засчитано.`, mainMenuInline());
        try { bot.sendMessage(Number(inviter), `✅ Ваш приглашённый ${from.first_name || ""} подтвердил подписку — +1 билет и +${INVITE_REWARD}₽.`); } catch(e){}
      } else {
        bot.sendMessage(chatId, `Это приглашение уже было засчитано.`, mainMenuInline());
      }
    } else {
      bot.sendMessage(chatId, `Вы не подписаны на канал. Подпишитесь и введите /confirm снова.`, mainMenuInline());
    }
  } catch (err) {
    console.error("confirm getChatMember error:", err && err.message);
    bot.sendMessage(chatId, `Ошибка проверки подписки. Убедитесь, что бот — админ канала.`, mainMenuInline());
  }
});

// === Информационные команды ===
bot.onText(/^\/tickets$/, (msg) => {
  const data = readData();
  const u = data.users[String(msg.from.id)];
  if (!u) return bot.sendMessage(msg.chat.id, "Нажми /start чтобы зарегистрироваться.", mainMenuInline());
  bot.sendMessage(msg.chat.id, `У тебя билетов: ${u.tickets}\nБаланс: ${u.balance || 0}₽`, mainMenuInline());
});
bot.onText(/^\/myref$/, async (msg) => {
  const data = readData();
  ensureUserObj(data, msg.from);
  const me = await bot.getMe();
  const link = `https://t.me/${me.username}?start=${msg.from.id}`;
  const count = (data.referrals[String(msg.from.id)] || []).length;
  bot.sendMessage(msg.chat.id, `Твоя ссылка: ${link}\nПодтверждённых: ${count}\nБилетов: ${data.users[String(msg.from.id)].tickets || 0}`, mainMenuInline());
});

// === Рулетка (команда и inline) ===
bot.onText(/^\/spin$/, (msg) => bot.emit("spin_command", msg));
bot.on("spin_command", async (msg) => {
  const data = readData();
  const uid = String(msg.from.id);
  const user = data.users[uid];
  const chatId = msg.chat ? msg.chat.id : (msg.chat && msg.chat.id) || msg.chat;
  if (!user) return bot.sendMessage(chatId, "Нажми /start чтобы зарегистрироваться.", mainMenuInline());

  // проверяем подписку на канал: если не подписан — блокируем рулетку
  const channelTarget = CHANNEL_ID || (CHANNEL_USERNAME ? `@${CHANNEL_USERNAME}` : null);
  if (channelTarget) {
    try {
      const member = await bot.getChatMember(channelTarget, Number(uid));
      if (!(member && (member.status === "member" || member.status === "creator" || member.status === "administrator"))) {
        return bot.sendMessage(chatId, "Для участия в рулетке нужно подписаться на канал. Нажми 'Проверить подписку'.", mainMenuInline());
      }
    } catch (err) {
      // если ошибка — предупреждаем, но не даём рулетку
      return bot.sendMessage(chatId, "Ошибка проверки подписки. Убедитесь, что бот — админ канала.", mainMenuInline());
    }
  }

  if ((user.tickets || 0) < TICKETS_FOR_SPIN) return bot.sendMessage(chatId, `Нужно ${TICKETS_FOR_SPIN} билетов, у тебя ${user.tickets || 0}.`, mainMenuInline());

  // списываем билеты
  user.tickets = 0;
  writeData(data);

  bot.sendMessage(chatId, `🎰 Крутим рулетку...`, mainMenuInline());
  const prize = spinPrize();
  if (prize.type === "nothing") {
    bot.sendMessage(chatId, `Увы — ничего не выпало. Попробуй позже.`, mainMenuInline());
    return;
  }
  if (prize.type === "tickets") {
    user.tickets = (user.tickets || 0) + prize.count;
    writeData(data);
    bot.sendMessage(chatId, `🎟 Поздравляем! Вы получили +${prize.count} билета(ов). Сейчас: ${user.tickets}`, mainMenuInline());
    return;
  }
  if (prize.type === "money") {
    user.balance = (user.balance || 0) + prize.amount;
    writeData(data);
    bot.sendMessage(chatId, `💸 Поздравляем! Вы выиграли ${prize.amount}₽. Баланс: ${user.balance}₽.\nДля вывода — /withdraw <16_цифр_карты>`, mainMenuInline());
    if (prize.amount >= 50 && ADMIN_ID) {
      try { bot.sendMessage(ADMIN_ID, `Пользователь ${uid} выиграл ${prize.amount}₽ в рулетке.`); } catch(e) {}
    }
    return;
  }
});

// === Withdraw (текстовая команда) ===
bot.onText(/^\/withdraw\s+(.+)/, (msg, match) => {
  const card = match && match[1] ? match[1].replace(/\s+/g,"") : "";
  const data = readData();
  const uid = String(msg.from.id);
  const user = data.users[uid];
  if (!user || !user.balance || user.balance < MIN_PAYOUT) {
    return bot.sendMessage(msg.chat.id, `Недостаточно средств для вывода. Минимум: ${MIN_PAYOUT}₽. Текущий баланс: ${user ? user.balance || 0 : 0}₽`, mainMenuInline());
  }
  const digits = card.match(/\d/g) || [];
  if (digits.length !== 16) {
    return bot.sendMessage(msg.chat.id, "Ошибка: номер карты должен содержать 16 цифр. Пример: /withdraw 4890490012345678", mainMenuInline());
  }
  const formatted = card.replace(/(\d{4})(\d{4})(\d{4})(\d{4})/, "$1 $2 $3 $4");
  const req = {
    id: Date.now() + "-" + Math.floor(Math.random()*10000),
    userId: uid,
    amount: user.balance,
    card: formatted,
    status: "pending",
    ts: Date.now()
  };
  user.balance = 0;
  data.withdrawals.push(req);
  writeData(data);

  bot.sendMessage(msg.chat.id, `Заявка создана: ${req.id}. Вывод будет обработан вручную (обычно в течение 24 часов).`, mainMenuInline());
  if (ADMIN_ID) {
    try {
      bot.sendMessage(ADMIN_ID, `Новая заявка на вывод:\nID: ${req.id}\nПользователь: ${uid}\nСумма: ${req.amount}₽\nКарта: ${req.card}\nДля подтверждения: /admin_pay ${req.id}\nДля отклонения: /admin_reject ${req.id}`);
    } catch(e){}
  }
});

// === Admin: управление заявками ===
bot.onText(/^\/admin_withdrawals$/, (msg) => {
  if (Number(msg.from.id) !== ADMIN_ID) return;
  const data = readData();
  if (!data.withdrawals || data.withdrawals.length === 0) return bot.sendMessage(msg.chat.id, "Нет заявок.");
  const lines = data.withdrawals.map(w => `${w.id} — ${w.userId} — ${w.amount}₽ — ${w.status}`).join("\n");
  bot.sendMessage(msg.chat.id, `Заявки:\n${lines}`);
});
bot.onText(/^\/admin_pay\s+(.+)$/, (msg, match) => {
  if (Number(msg.from.id) !== ADMIN_ID) return;
  const id = match[1].trim();
  const data = readData();
  const idx = data.withdrawals.findIndex(w => w.id === id && w.status === "pending");
  if (idx === -1) return bot.sendMessage(msg.chat.id, "Заявка не найдена или уже обработана.");
  const w = data.withdrawals[idx];
  w.status = "paid";
  w.paidAt = Date.now();
  writeData(data);
  bot.sendMessage(msg.chat.id, `Заявка ${id} помечена как оплаченная.`);
  try { bot.sendMessage(Number(w.userId), `Ваша заявка ${id} на сумму ${w.amount}₽ помечена как оплаченная.`); } catch(e){}
});
bot.onText(/^\/admin_reject\s+(.+)$/, (msg, match) => {
  if (Number(msg.from.id) !== ADMIN_ID) return;
  const id = match[1].trim();
  const data = readData();
  const idx = data.withdrawals.findIndex(w => w.id === id && w.status === "pending");
  if (idx === -1) return bot.sendMessage(msg.chat.id, "Заявка не найдена или уже обработана.");
  const w = data.withdrawals[idx];
  w.status = "rejected";
  if (data.users[w.userId]) {
    data.users[w.userId].balance = (data.users[w.userId].balance || 0) + w.amount;
  }
  writeData(data);
  bot.sendMessage(msg.chat.id, `Заявка ${id} отклонена и сумма возвращена пользователю.`);
  try { bot.sendMessage(Number(w.userId), `Ваша заявка ${id} отклонена. Сумма возвращена на баланс.`); } catch(e){}
});

// === Inline callbacks (меню) ===
bot.on("callback_query", async (q) => {
  const data = readData();
  const from = q.from;
  const chatId = q.message.chat.id;
  const text = q.data;

  try {
    if (text === "menu_profile") {
      const u = data.users[String(from.id)] || { balance: 0, tickets: 0, invites: [] };
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, `👤 Профиль\nБаланс: ${u.balance || 0}₽\nБилетов: ${u.tickets || 0}\nПригласил: ${u.invites ? u.invites.length : 0}`, mainMenuInline());
    }
    if (text === "menu_ref") {
      const me = await bot.getMe();
      const link = `https://t.me/${me.username}?start=${from.id}`;
      const cnt = (data.referrals[String(from.id)] || []).length;
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, `Приглашайте друзей!\nВаша ссылка:\n${link}\nПодтверждённых: ${cnt}`, mainMenuInline());
    }
    if (text === "menu_spin") {
      await bot.answerCallbackQuery(q.id);
      return bot.emit("spin_command", { chat: { id: chatId }, from });
    }
    if (text === "menu_withdraw") {
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, `Для вывода напиши команду:\n/withdraw <16_цифр_карты>\n(минимум: ${MIN_PAYOUT}₽)`, mainMenuInline());
    }
    if (text === "menu_rules") {
      await bot.answerCallbackQuery(q.id);
      return bot.sendMessage(chatId, `Правила:\n• 1 приглашение = ${INVITE_REWARD}₽ и +1 билет\n• Минимум для вывода: ${MIN_PAYOUT}₽\n• Для подтверждения приглашения: подпишись на канал и введи /confirm`, mainMenuInline());
    }
    if (text === "menu_check_sub") {
      await bot.answerCallbackQuery(q.id);
      const channelTarget = CHANNEL_ID || (CHANNEL_USERNAME ? `@${CHANNEL_USERNAME}` : null);
      if (!channelTarget) return bot.sendMessage(chatId, "Канал не настроен у бота.", mainMenuInline());
      try {
        const member = await bot.getChatMember(channelTarget, from.id);
        if (member && (member.status === "member" || member.status === "creator" || member.status === "administrator")) {
          return bot.sendMessage(chatId, "Подписка подтверждена! Если вы пришли по реферальной ссылке — введите /confirm.", mainMenuInline());
        } else {
          return bot.sendMessage(chatId, `Вы не подписаны. Подпишитесь и нажмите 'Проверить подписку' снова.`, mainMenuInline());
        }
      } catch (err) {
        console.error("check sub error:", err && err.message);
        return bot.sendMessage(chatId, "Ошибка проверки подписки. Убедитесь, что бот — админ канала.", mainMenuInline());
      }
    }

    await bot.answerCallbackQuery(q.id, { text: "Нажата кнопка." });
  } catch (e) {
    console.error("callback_query error:", e && e.message);
  }
});

// fallback noop
bot.on("message", () => {});